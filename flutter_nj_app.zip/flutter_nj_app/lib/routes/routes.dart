import 'package:flutter/material.dart';
import 'package:flutter_nj_app/screens/quiz_screen.dart';

var routes = <String, WidgetBuilder>{
  'quiz': (context) => QuizScreen(),
};
